import React, { useState, useEffect } from 'react';
import HomeHeroSection from './components/HomeHeroSection';
import HomeTestimonialsSection from './components/HomeTestimonialsSection';
import PetUploadForm from './components/PetUploadForm';
import PetList from './components/PetList';
import PetSearch from './components/PetSearch';
import UserProfilePage from './components/UserProfilePage';
import UserProfileEditForm from './components/UserProfileEditForm';

const App = () => {
  const [currentPage, setCurrentPage] = useState('home');
  const [petsForAdoption, setPetsForAdoption] = useState([]);
  const [editingPet, setEditingPet] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredPets, setFilteredPets] = useState([]);
  
  // Datos de usuario simulados (sin base de datos)
  const [currentUser, setCurrentUser] = useState({
    id: 'user123',
    name: 'Juan Pérez',
    email: 'juan.perez@example.com',
    profilePicture: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    location: 'Ciudad de México, México',
    phone: '+52 55 1234 5678',
    memberSince: '15 de Enero, 2023',
    bio: 'Amante de los animales y defensor de la adopción. Me encanta pasar tiempo al aire libre con mis mascotas y ayudar a otros a encontrar a sus compañeros ideales.',
  });

  useEffect(() => {
    const lowercasedSearchTerm = searchTerm.toLowerCase();
    const results = petsForAdoption.filter(pet =>
      pet.name.toLowerCase().includes(lowercasedSearchTerm) ||
      pet.breed.toLowerCase().includes(lowercasedSearchTerm) ||
      pet.description.toLowerCase().includes(lowercasedSearchTerm)
    );
    setFilteredPets(results);
  }, [searchTerm, petsForAdoption]);

  const handleAdoptClick = () => {
    alert('¡Vamos a adoptar!');
    setCurrentPage('petList');
  };

  const handleLearnMoreClick = () => {
    alert('Conoce más sobre la adopción.');
  };

  const handlePetSubmit = (newPet) => {
    if (editingPet) {
      setPetsForAdoption((prevPets) =>
        prevPets.map((pet) => (pet.id === editingPet.id ? newPet : pet))
      );
      alert(`¡${newPet.name} ha sido actualizada!`);
      setEditingPet(null);
    } else {
      setPetsForAdoption((prevPets) => [...prevPets, newPet]);
      alert(`¡${newPet.name} ha sido agregada para adopción!`);
    }
    setCurrentPage('petList');
  };

  const handleEditPet = (petToEdit) => {
    setEditingPet(petToEdit);
    setCurrentPage('upload');
  };

  const handleDeletePet = (petId) => {
    if (window.confirm('¿Estás seguro de que quieres eliminar esta mascota?')) {
      setPetsForAdoption((prevPets) => prevPets.filter((pet) => pet.id !== petId));
      alert('Mascota eliminada con éxito.');
    }
  };

  const handleSearchChange = (term) => {
    setSearchTerm(term);
  };

  const handleEditProfile = () => {
    setCurrentPage('editProfile');
  };

  const handleSaveProfile = (updatedUser) => {
    setCurrentUser(updatedUser);
    alert('¡Perfil actualizado con éxito!');
    setCurrentPage('profile');
  };

  const handleCancelEditProfile = () => {
    setCurrentPage('profile');
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Navegación simple para cambiar de página */}
      <nav className="bg-white shadow-md p-4 flex justify-center space-x-4">
        <button
          onClick={() => { setCurrentPage('home'); setEditingPet(null); setSearchTerm(''); }}
          className={`px-4 py-2 rounded-lg font-medium ${currentPage === 'home' ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-200'}`}
        >
          Inicio
        </button>
        <button
          onClick={() => { setCurrentPage('upload'); setEditingPet(null); setSearchTerm(''); }}
          className={`px-4 py-2 rounded-lg font-medium ${currentPage === 'upload' ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-200'}`}
        >
          Subir Mascota
        </button>
        <button
          onClick={() => { setCurrentPage('petList'); setEditingPet(null); }}
          className={`px-4 py-2 rounded-lg font-medium ${currentPage === 'petList' ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-200'}`}
        >
          Ver Mascotas
        </button>
        <button
          onClick={() => { setCurrentPage('profile'); setEditingPet(null); setSearchTerm(''); }}
          className={`px-4 py-2 rounded-lg font-medium ${currentPage === 'profile' || currentPage === 'editProfile' ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-200'}`}
        >
          Mi Perfil
        </button>
      </nav>

      {currentPage === 'home' && (
        <>
          <HomeHeroSection
            onAdoptClick={handleAdoptClick}
            onLearnMoreClick={handleLearnMoreClick}
          />
          <HomeTestimonialsSection />
        </>
      )}

      {currentPage === 'upload' && (
        <PetUploadForm onPetSubmit={handlePetSubmit} initialPetData={editingPet} />
      )}

      {currentPage === 'petList' && (
        <>
          <PetSearch searchTerm={searchTerm} onSearchChange={handleSearchChange} />
          <PetList pets={filteredPets} onEditPet={handleEditPet} onDeletePet={handleDeletePet} />
        </>
      )}

      {currentPage === 'profile' && (
        <UserProfilePage user={currentUser} onEditProfile={handleEditProfile} />
      )}

      {currentPage === 'editProfile' && (
        <UserProfileEditForm user={currentUser} onSave={handleSaveProfile} onCancel={handleCancelEditProfile} />
      )}

      {/* Aquí irían otras páginas según el estado de currentPage */}
    </div>
  );
};

export default App;

// DONE