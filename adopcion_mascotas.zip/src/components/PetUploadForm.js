import React, { useState } from 'react';

const PetUploadForm = ({ onPetSubmit }) => {
  const [petName, setPetName] = useState('');
  const [petType, setPetType] = useState('');
  const [petBreed, setPetBreed] = useState('');
  const [petAge, setPetAge] = useState('');
  const [petDescription, setPetDescription] = useState('');
  const [petImage, setPetImage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!petName || !petType || !petBreed || !petAge || !petDescription || !petImage) {
      alert('Por favor, llena todos los campos para subir a tu mascota.');
      return;
    }

    const newPet = {
      id: Date.now(), // Genera un ID único simple
      name: petName,
      type: petType,
      breed: petBreed,
      age: petAge,
      description: petDescription,
      image: petImage,
      adopted: false,
    };

    onPetSubmit(newPet);
    // Limpiar formulario
    setPetName('');
    setPetType('');
    setPetBreed('');
    setPetAge('');
    setPetDescription('');
    setPetImage('');
  };

  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-100">
      <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-xl p-8">
        <h2 className="text-3xl sm:text-4xl font-extrabold text-gray-900 mb-8 text-center">
          Pon tu Mascota en Adopción
        </h2>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="petName" className="block text-sm font-medium text-gray-700">
              Nombre de la Mascota
            </label>
            <input
              type="text"
              id="petName"
              className="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition"
              value={petName}
              onChange={(e) => setPetName(e.target.value)}
              required
            />
          </div>

          <div>
            <label htmlFor="petType" className="block text-sm font-medium text-gray-700">
              Tipo de Mascota
            </label>
            <select
              id="petType"
              className="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition"
              value={petType}
              onChange={(e) => setPetType(e.target.value)}
              required
            >
              <option value="">Selecciona un tipo</option>
              <option value="Perro">Perro</option>
              <option value="Gato">Gato</option>
              <option value="Otro">Otro</option>
            </select>
          </div>

          <div>
            <label htmlFor="petBreed" className="block text-sm font-medium text-gray-700">
              Raza
            </label>
            <input
              type="text"
              id="petBreed"
              className="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition"
              value={petBreed}
              onChange={(e) => setPetBreed(e.target.value)}
              required
            />
          </div>

          <div>
            <label htmlFor="petAge" className="block text-sm font-medium text-gray-700">
              Edad (años)
            </label>
            <input
              type="number"
              id="petAge"
              className="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition"
              value={petAge}
              onChange={(e) => setPetAge(e.target.value)}
              min="0"
              required
            />
          </div>

          <div>
            <label htmlFor="petDescription" className="block text-sm font-medium text-gray-700">
              Descripción
            </label>
            <textarea
              id="petDescription"
              rows="4"
              className="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition resize-none"
              value={petDescription}
              onChange={(e) => setPetDescription(e.target.value)}
              required
            ></textarea>
          </div>

          <div>
            <label htmlFor="petImage" className="block text-sm font-medium text-gray-700">
              URL de la Imagen
            </label>
            <input
              type="url"
              id="petImage"
              className="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition"
              value={petImage}
              onChange={(e) => setPetImage(e.target.value)}
              placeholder="Ej: https://ejemplo.com/imagen-mascota.jpg"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold shadow-md hover:bg-blue-700 transform hover:scale-105 transition-all duration-300 ease-in-out"
          >
            Subir Mascota para Adopción
          </button>
        </form>
      </div>
    </section>
  );
};

export default PetUploadForm;