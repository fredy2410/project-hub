import React from 'react';

const PetSearch = ({ searchTerm, onSearchChange }) => {
  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8 bg-white shadow-md rounded-b-2xl">
      <div className="max-w-3xl mx-auto">
        <input
          type="text"
          placeholder="Buscar mascotas por nombre, raza o descripción..."
          className="w-full px-6 py-3 border border-gray-300 rounded-full shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition text-lg"
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
        />
      </div>
    </div>
  );
};

export default PetSearch;