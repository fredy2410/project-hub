import React from 'react';
import PetCard from './PetCard';

const PetList = ({ pets, onEditPet, onDeletePet }) => {
  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-100">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl sm:text-4xl font-extrabold text-gray-900 mb-12 text-center">
          Mascotas Disponibles para Adopción
        </h2>
        {pets.length === 0 ? (
          <p className="text-center text-gray-600 text-lg">
            No hay mascotas disponibles en este momento. ¡Sé el primero en subir una!
          </p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {pets.map((pet) => (
              <PetCard
                key={pet.id}
                pet={pet}
                onEdit={onEditPet}
                onDelete={onDeletePet}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default PetList;