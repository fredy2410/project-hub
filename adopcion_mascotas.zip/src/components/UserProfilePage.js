import React from 'react';

const UserProfilePage = ({ user, onEditProfile }) => {
  if (!user) {
    return (
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-100 min-h-screen flex items-center justify-center">
        <div className="text-center text-gray-600 text-lg">
          Por favor, inicia sesión para ver tu perfil.
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-100 min-h-screen">
      <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-xl p-8 sm:p-10 lg:p-12">
        <div className="flex flex-col sm:flex-row items-center sm:items-start space-y-6 sm:space-y-0 sm:space-x-8">
          <div className="flex-shrink-0">
            <img
              src={user.profilePicture || "https://via.placeholder.com/150/E0E7FF/4338CA?text=User"}
              alt="Foto de perfil"
              className="w-32 h-32 rounded-full object-cover border-4 border-blue-500 shadow-md"
            />
          </div>
          <div className="text-center sm:text-left flex-grow">
            <h2 className="text-3xl sm:text-4xl font-extrabold text-gray-900 mb-2">
              {user.name}
            </h2>
            <p className="text-lg text-gray-600 mb-4">
              {user.email}
            </p>
            <div className="space-y-2 text-gray-700">
              <p>
                <span className="font-semibold">Ubicación:</span> {user.location || 'No especificada'}
              </p>
              <p>
                <span className="font-semibold">Teléfono:</span> {user.phone || 'No especificado'}
              </p>
              <p>
                <span className="font-semibold">Miembro desde:</span> {user.memberSince || 'Fecha no disponible'}
              </p>
            </div>
            <p className="text-gray-800 mt-6 leading-relaxed">
              <span className="font-semibold">Acerca de mí:</span> {user.bio || 'Aún no has escrito una biografía. ¡Cuéntanos algo sobre ti!'}
            </p>
            <button
              onClick={onEditProfile}
              className="mt-8 bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold shadow-md hover:bg-blue-700 transform hover:scale-105 transition-all duration-300 ease-in-out"
            >
              Editar Perfil
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default UserProfilePage;