import React from 'react';

const PetCard = ({ pet, onEdit, onDelete }) => {
  return (
    <div className="bg-white rounded-2xl shadow-xl overflow-hidden transform transition-transform duration-300 hover:scale-105 hover:shadow-2xl">
      <img
        src={pet.image}
        alt={pet.name}
        className="w-full h-48 object-cover"
      />
      <div className="p-6">
        <h3 className="text-2xl font-bold text-gray-900 mb-2">{pet.name}</h3>
        <p className="text-gray-600 text-sm mb-1">
          <span className="font-semibold">Tipo:</span> {pet.type}
        </p>
        <p className="text-gray-600 text-sm mb-1">
          <span className="font-semibold">Raza:</span> {pet.breed}
        </p>
        <p className="text-gray-600 text-sm mb-4">
          <span className="font-semibold">Edad:</span> {pet.age} años
        </p>
        <p className="text-gray-700 text-base mb-4 line-clamp-3">
          {pet.description}
        </p>
        <div className="flex justify-between items-center mt-4">
          <button
            onClick={() => onEdit(pet)}
            className="bg-yellow-500 text-white px-4 py-2 rounded-lg font-semibold hover:bg-yellow-600 transition-colors text-sm"
          >
            Editar
          </button>
          <button
            onClick={() => onDelete(pet.id)}
            className="bg-red-500 text-white px-4 py-2 rounded-lg font-semibold hover:bg-red-600 transition-colors text-sm"
          >
            Eliminar
          </button>
        </div>
      </div>
    </div>
  );
};

export default PetCard;