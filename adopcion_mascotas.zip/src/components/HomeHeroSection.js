import React from 'react';

const HomeHeroSection = ({ onAdoptClick, onLearnMoreClick }) => {
  return (
    <section className="relative bg-gradient-to-r from-blue-500 to-purple-600 text-white py-20 px-4 sm:px-6 lg:px-8 flex flex-col items-center justify-center text-center min-h-screen">
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1583337130417-3346a5fe268a?q=80&w=2080&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
          alt="Perro y gato abrazándose"
          className="w-full h-full object-cover opacity-30"
        />
      </div>
      <div className="relative z-10 max-w-4xl mx-auto">
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold leading-tight mb-6 drop-shadow-lg">
          Encuentra a tu Compañero Peludo Ideal
        </h1>
        <p className="text-lg sm:text-xl mb-10 opacity-90">
          Miles de mascotas esperan un hogar lleno de amor. ¡Adopta, no compres!
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <button
            onClick={onAdoptClick}
            className="bg-white text-blue-600 px-8 py-3 rounded-full text-lg font-semibold shadow-lg hover:bg-gray-100 transform hover:scale-105 transition-all duration-300 ease-in-out"
          >
            Adoptar Ahora
          </button>
          <button
            onClick={onLearnMoreClick}
            className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-full text-lg font-semibold shadow-lg hover:bg-white hover:text-blue-600 transform hover:scale-105 transition-all duration-300 ease-in-out"
          >
            Saber Más
          </button>
        </div>
      </div>
    </section>
  );
};

export default HomeHeroSection;