import React from 'react';

const HomeTestimonialsSection = () => {
  const testimonials = [
    {
      id: 1,
      quote: "Adoptar a Max ha sido la mejor decisión de mi vida. Es un compañero increíble y ha llenado mi hogar de alegría. ¡Gracias por esta oportunidad!",
      author: "Ana G.",
      pet: "Max (Perro)",
      image: "https://images.unsplash.com/photo-1543463122-d2022122212c?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    },
    {
      id: 2,
      quote: "Nunca pensé que un gato pudiera ser tan cariñoso como Luna. Desde que llegó, mis días son más divertidos y llenos de ronroneos. ¡Anímense a adoptar!",
      author: "Carlos R.",
      pet: "Luna (Gata)",
      image: "https://images.unsplash.com/photo-1574144611937-0858060f4e71?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    },
    {
      id: 3,
      quote: "Mi vida cambió por completo con la llegada de Rocky. Es un perro lleno de energía y amor. La adopción es un acto de amor que te devuelve el doble.",
      author: "Sofía M.",
      pet: "Rocky (Perro)",
      image: "https://images.unsplash.com/photo-1598133894832-e647542bc36a?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    },
  ];

  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
      <div className="max-w-6xl mx-auto text-center">
        <h2 className="text-3xl sm:text-4xl font-extrabold text-gray-900 mb-12">
          Historias que Inspiran
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <div
              key={testimonial.id}
              className="bg-white rounded-2xl shadow-xl p-8 flex flex-col items-center text-center transform transition-transform duration-300 hover:scale-105 hover:shadow-2xl"
            >
              <div className="w-24 h-24 rounded-full overflow-hidden mb-6 border-4 border-blue-500 shadow-md">
                <img
                  src={testimonial.image}
                  alt={testimonial.pet}
                  className="w-full h-full object-cover"
                />
              </div>
              <p className="text-lg text-gray-700 mb-6 italic leading-relaxed">
                "{testimonial.quote}"
              </p>
              <p className="font-semibold text-blue-600 text-xl">
                {testimonial.author}
              </p>
              <p className="text-gray-500 text-sm mt-1">
                Adoptó a {testimonial.pet}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HomeTestimonialsSection;